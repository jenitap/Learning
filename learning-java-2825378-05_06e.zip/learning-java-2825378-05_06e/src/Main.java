public class Main {

    public static void main(String[] args) {
        double result = Math.pow(2, 5);
        System.out.println(result);

        Math.
    }

}
